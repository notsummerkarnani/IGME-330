import { showMeal } from "./utils.js";

for (let k of Object.keys(localStorage)) {
    if (k != 'undefined' && JSON.parse(localStorage[k])) {
        showMeal(JSON.parse(localStorage[k]));
    }
}

document.querySelector("#clear-btn").onclick = (e) => {
    localStorage.clear()
    document.querySelector("#output").innerHTML = ""
}