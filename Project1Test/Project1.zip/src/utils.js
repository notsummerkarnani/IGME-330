const loadFile = (url, callback) => {
    const fetchPromise = async() => {
        const response = await fetch(url);
        callback(await response.json());
    }
    fetchPromise().catch(alert);
};

let favourites = []; //arr holding the favourites
if (localStorage != null) {
    for (let k of Object.keys(localStorage)) {
        if (k != 'undefined')
            favourites.push(JSON.parse(localStorage[k]));
        //console.log(JSON.parse(localStorage[k]));
    }
}

function showMeal(mcObj) {

    const mealCard = document.createElement("meal-card");

    if (!mcObj.strMeal) {
        mealCard.dataset.strMeal = "No Name found";
    } else {
        mealCard.dataset.strMeal = mcObj.strMeal;
    }

    if (!mcObj.strArea)
        mealCard.dataset.strArea = "Unknown";
    else {
        mealCard.dataset.strArea = mcObj.strArea;
    }

    if (!mcObj.strMealThumb)
        mealCard.dataset.strMealThumb = "";
    else {
        mealCard.dataset.strMealThumb = mcObj.strMealThumb;
    }

    if (!mcObj.strIngredients || !mcObj.strMeasurements) {
        let ingredients = [];
        let measurements = [];
        //format html for measure an ingrdients and send them as a string
        for (let i = 0; i < 20; i++) {
            if (!mcObj[`strIngredient${i+1}`] || !mcObj[`strMeasure${i+1}`]) {

            } else {
                ingredients.push(mcObj[`strIngredient${i+1}`]); // = `${mcObj[`strIngredient${i+1}`]}`;
                measurements.push(mcObj[`strMeasure${i+1}`]); // = `${mcObj[`strIngredient${i+1}`]}`;
                //mealCard.dataset[`strIngredient${i}`] = `${mcObj[`strIngredient${i+1}`]}`;
            }
        }
        mealCard.dataset.strIngredients = ingredients;
        mealCard.dataset.strMeasurements = measurements;
    } else {
        mealCard.dataset.strIngredients = mcObj.strIngredients;
        mealCard.dataset.strMeasurements = mcObj.strMeasurements;
    }

    if (!mcObj.strInstructions)
        mealCard.dataset.strInstructions = "";
    else {
        mealCard.dataset.strInstructions = mcObj.strInstructions;
    }

    if (!mcObj.strCategory)
        mealCard.dataset.strCategory = "";
    else {
        mealCard.dataset.strCategory = mcObj.strCategory;
    }

    if (!mcObj.strFavourite)
        mealCard.dataset.strFavourite = "false";
    else {
        mealCard.dataset.strFavourite = mcObj.strFavourite;
    }

    //check if meal is already in favourites 
    if (favourites.length > 0) {
        favourites.forEach(element => {
            if (element != null && element.strMeal == mealCard.dataset.strMeal) {
                mealCard.dataset.strFavourite = "true";
            }
        })
    }

    return document.querySelector("#output").appendChild(mealCard);
}

//param is the dataset of the obj
//
function addfavourite(card) {
    const arrLength = favourites.length;

    if (!card) { return; }

    if (arrLength > 0) {
        for (let i = 0; i < arrLength; i++) {
            if (favourites[i] != null && favourites[i].strMeal == card.strMeal) {
                return;
            }
        }
        favourites.push(card);
        localStorage.setItem(`srk7473-favourites-${(arrLength)}`, JSON.stringify(favourites[arrLength]));
        return;
    }
    favourites.push(card);
    localStorage.setItem(`srk7473-favourites-${(arrLength)}`, JSON.stringify(favourites[arrLength]));
}

function removefavourite(card) {
    const arrLength = favourites.length;

    if (!card) { return; }

    if (arrLength > 0) {
        for (let i = 0; i < arrLength; i++) {
            if (localStorage.getItem(`srk7473-favourites-${i}`))
                if (favourites[i].strMeal == card.strMeal) {

                    favourites[i] = null;
                    localStorage.removeItem(`srk7473-favourites-${i}`);

                }


                // let temp = favourites[i + 1];
                // favourites[i] = temp;
                // localStorage.setItem(localStorage[`srk7473-favourites-${i}`], localStorage[`srk7473-favourites-${i+1}`]);
        }
    }


}

export { loadFile, showMeal, addfavourite, removefavourite };