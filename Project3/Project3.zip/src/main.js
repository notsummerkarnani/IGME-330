/*
	main.js is primarily responsible for hooking up the UI to the rest of the application 
	and setting up the main event loop
*/

// We will write the functions in this file in the traditional ES5 way
// In this instance, we feel the code is more readable if written this way
// If you want to re-write these as ES6 arrow functions, to be consistent with the other files, go ahead!

import * as utils from './utils.js';
import * as canvas from './canvas.js';
import Rect from './rect.js';


// More API functions here:
// https://github.com/googlecreativelab/teachablemachine-community/tree/master/libraries/pose

// the link to your model provided by Teachable Machine export panel
const URL = 'https://teachablemachine.withgoogle.com/models/7tEeCg_ln/';

let model, webcam, ctx, fps = 60,
    canvasElement,
    wrists = {};

const GAMESTATE = Object.freeze({
    MENU: Symbol("MENU"),
    GAME: Symbol("GAME"),
    PAUSE: Symbol("PAUSE"),
    END: Symbol("END")
});

let state = GAMESTATE.MENU;

let enemies = [];


async function init(tmPose, imageData) {

    console.log("init called");
    console.log(`Testing utils.getRandomColor() import: ${utils.getRandomColor()}`);

    const modelURL = URL + 'model.json';
    const metadataURL = URL + 'metadata.json';

    // load the model and metadata
    // Refer to tmPose.loadFromFiles() in the API to support files from a file picker
    model = await tmPose.load(modelURL, metadataURL);

    // Convenience function to setup a webcam
    const flip = true; // whether to flip the webcam
    webcam = new tmPose.Webcam(900, 400, flip); // width, height, flip
    await webcam.setup(); // request access to the webcam
    webcam.play();
    window.requestAnimationFrame(loop);

    // append/get elements to the DOM
    canvasElement = document.querySelector("canvas"); // hookup <canvas> element
    setupUI(canvasElement);
    canvas.setupCanvas(canvasElement);
    ctx = canvasElement.getContext('2d');

    enemies = utils.createImageSprite(imageData.cage1, Rect);
    console.log(enemies);
    loop();
}

async function predict() {
    // Prediction #1: run input through posenet
    // estimatePose can take in an image, video or canvas html element
    const {
        pose,
        posenetOutput
    } = await model.estimatePose(webcam.canvas);

    wrists.left = pose.keypoints[9];
    wrists.right = pose.keypoints[10];

    canvas.drawPose(pose);
}

function setupUI(canvasElement) {
    // A - hookup fullscreen button
    const fsButton = document.querySelector("#fsButton");

    // add .onclick event to button
    fsButton.onclick = e => {
        console.log("init called");
        utils.goFullscreen(canvasElement);
    };

    playButton.onclick = e => {
        if (state != GAMESTATE.GAME) {
            state = GAMESTATE.GAME;
            playButton.innerText = 'Pause';


        } else {
            state = GAMESTATE.PAUSE;
            playButton.innerText = 'Play';
            canvas.fillText(ctx, "Game Paused", canvasElement.width / 2, canvasElement.height / 2 - 20, "40pt 'Press Start 2P', cursive", "red");
            canvas.strokeText(ctx, "Game Paused", canvasElement.width / 2, canvasElement.height / 2 - 20, "40pt 'Press Start 2P', cursive", "black", 2);

        }
    }
} // end setupUI

async function loop() {
    window.requestAnimationFrame(loop, 1 / fps);

    switch (state) {
        case GAMESTATE.MENU:

            break;
        case GAMESTATE.GAME:
            canvas.reset();
            webcam.update(); // update the webcam frame
            for (let s of enemies) {
                if (s.x < 0 || s.x > canvasElement.width) {
                    s.reflectX();
                }
                if (s.y < 0 || s.y > canvasElement.height) {
                    s.reflectY();
                }

                s.move();
                // draw sprites
                s.draw(ctx);

                if (s.getRect().containsPoint(wrists.left) || s.getRect().containsPoint(wrists.right)) {
                    s.speed = 0;
                }
            } // end for

            //enemies = enemies.filter(s => { s.speed == 0 })
            console.log(enemies);
            canvas.drawHUD(0, 0);
            await predict();
            break;
        case GAMESTATE.PAUSE:

            break;
        case GAMESTATE.END:

            break;
    }
}

export { init };