import "https://cdnjs.cloudflare.com/ajax/libs/pixi.js/5.1.3/pixi.min.js"

export class Enemy extends PIXI.Graphics {
    constructor(radius, x = 0, y = 0) {
        super(app.loader.resources["images/enemy.png"].texture);
        this.anchor.set(.5, .5);
        this.scale.set(0.1);


        this.x = x;
        this.y = y;
        this.radius = radius;

        //variables
        this.angularSpeed = 0;
        this.fwd = { x: -Math.cos(this.angularSpeed), y: -Math.sin(this.angularSpeed) };
        this.speed = 200;
        this.isAlive = true;
    }

    move(dt = 1 / 60) {
        this.angularSpeed += .3 * Math.random();

        this.x += this.fwd.x * this.speed * dt;
        this.y += Math.sin(this.angularSpeed) * 2;
    }

    reflectX() {
        this.fwd.x *= -1;
    }
}

export class Circle extends PIXI.Sprite {
    constructor(radius, x = 0, y = 0) {
        super(app.loader.resources["images/enemy2.png"].texture);
        this.anchor.set(.5, .5);
        this.scale.set(0.1);

        this.x = x;
        this.y = y;
        this.radius = radius;

        //variables
        this.fwd = getRandomUnitVector();
        this.speed = 100;
        this.isAlive = true;
    }

    move(dt = 1 / 60) {
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }

    reflectX() {
        this.fwd.x *= -1;
    }

    reflectY() {
        this.fwd.y *= -1;
    }
}