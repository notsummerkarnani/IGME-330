import * as main from "./main.js";
import { loadImages } from './utils.js';

import "https://cdn.jsdelivr.net/npm/@teachablemachine/pose@0.8.3/dist/teachablemachine-pose.min.js"


const imageSources = {
    cage1: '../media/test.png',
};

// loadImages(imageSourcesObject,callback);
loadImages(imageSources, (imageData) => { main.init(tmPose, imageData) });

// window.onload = () => {
//     console.log("window.onload called");
//     // 1 - do preload here - load fonts, images, additional sounds, etc...
//     image = new Image(100, 100);
//     image.src = ''
//         // 2 - start up app
//     main.init(tmPose);
// }